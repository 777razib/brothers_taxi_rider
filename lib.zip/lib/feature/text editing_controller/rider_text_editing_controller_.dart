import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class RiderTextEditingController extends GetxController{

  TextEditingController riderName = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController riderImage = TextEditingController();

}