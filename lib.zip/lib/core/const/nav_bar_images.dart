class NavBarImages {
  static const String acthome = "assets/icons/home_act.png";
  static const String passhome = "assets/icons/home_pas.png";

  static const String actCalculate = "assets/icons/calculator_act.png";
  static const String passCalculate = "assets/icons/calculator_pas.png";

  static const String actprofile = "assets/icons/profile_act.png";
  static const String passprofile = "assets/icons/profile_pas.png";

  static const String actChat = "assets/icons/chat_act.png";
  static const String passChat = "assets/icons/chat_pas.png";
}
