class AppTexts {
 // static const String appName = "Renbix";
 
}
