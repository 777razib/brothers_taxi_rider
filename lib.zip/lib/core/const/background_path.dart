class BackgroundImagePath {
 // static const String forgetPasswordBackground = "assets/backgrounds/forgetPasswordBackground.png";
}
